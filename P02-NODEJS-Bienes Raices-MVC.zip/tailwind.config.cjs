
module.exports = {
  content: ['./views/**/*.pug'],
  theme: {
    extend: {},
  },
  plugins: [],
}

