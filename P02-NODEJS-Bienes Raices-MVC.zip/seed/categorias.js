const categorias = [
    {
        categoriaPropiedad: 'Casa'
    },{
        categoriaPropiedad: 'Departamento'
    }, {
        categoriaPropiedad: 'Bodega'
    }, {
        categoriaPropiedad: 'Terreno'
    }, {
        categoriaPropiedad: 'Cabaña'
    }
]

export default categorias;